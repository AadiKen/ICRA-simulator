# Task: validate the backstepping controller — seed 30003, then 200-seed calibration

## Order of operations

Run Step 1 first. If it reveals something badly broken (crash, wildly
divergent behavior, not just "still fails"), stop and report before
spending the full 200-seed run. Otherwise proceed to Step 2 regardless of
Step 1's pass/fail outcome - 30003 is expected to be hard and its result
alone shouldn't block the larger validation.

**Adopted controller for both steps** (do not modify): backstepping,
Lambda=0.9523809524, Kp=[485.995033, 485.995033, 485.995033],
Kd=[849.689997, 849.689997, 849.689997], on top of the existing M/C/D,
allocator, and waypoint logic - exactly as currently implemented in
`vehicle-c-sliding-mode-controller.ts` (the backstepping mode of it, not
the sliding-mode layer, which was rejected).

## Step 1 — Seed 30003

Run seed 30003 under the adopted backstepping configuration. Report
success/fail, final-leg-gated closest approach, and saturation - same
metrics as every other seed in this investigation. This seed was excluded
from all tuning decisions (adverse wind/current, deliberately not used to
drive any gain or architecture choice) but was never excluded from final
validation - report its result plainly, whatever it is.

## Step 2 — 200-seed terminal-radius calibration

Reuse the existing `vehicle-c-radius-calibration.ts` harness and protocol
exactly as before: 200 held-out seeds (30100-30299, same range as the
original PID calibration, so results are directly comparable), same
Vehicle C parameters (length 3.5m, defensible minimum 1.75m, defensibility
ceiling 17.5m), same candidate radii sweep, same 40-70% best-classical
success band, same GPS-floor sanity check (still labeled borrowed/
unverified for Vehicle C, as before).

**The only change: swap the controller from LOS-PID-v2 + full compensation
to the adopted backstepping configuration.** Nothing else about the
protocol changes - same seeds, same sanity checks, same output discipline
(candidate-not-frozen, human approval required, do not touch
`task-contract-frozen.json`).

Report:
- The full candidate-radii table (same shape as the original:
  untrained/los_pid-equivalent/los_speedcap-equivalent/best rates per
  radius), so it's directly comparable line-by-line to the original
  26%-at-17.5m result.
- Success rate specifically at the current frozen 2m radius, not just the
  17.5m ceiling - this is the number that answers "is it acceptable" most
  directly, since 2m remains the actual frozen success definition unless
  and until a different radius is explicitly adopted.
- Whether an eligible radius now exists in the 40-70% band (there wasn't
  one before, at any radius up to 17.5m).
- A direct, explicit comparison to the original PID-based calibration's
  results, seed range confirmed non-overlapping with all seeds used in
  developing/tuning the backstepping controller (30000, 30003, 30007,
  30013, 30048).

## Explicit prohibitions

- Do not modify the controller, gains, M/C/D, allocator, or waypoint logic
  in this task - validation only.
- Do not touch `task-contract-frozen.json` or freeze anything.
- Do not run the full 30000-30049 production sweep - that remains a
  separate, later decision.
- Do not modify or re-run the sliding-mode variant - it's already
  rejected.

## Report back with

1. Seed 30003's result (Step 1).
2. The full candidate-radii table and 2m-specific success rate (Step 2).
3. Whether an eligible radius exists in the 40-70% band.
4. Direct comparison to the original PID-based calibration.
