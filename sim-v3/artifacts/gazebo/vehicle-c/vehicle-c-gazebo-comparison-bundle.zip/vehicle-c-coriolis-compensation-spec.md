# Task: Coriolis feedforward compensation for Vehicle C

## What this is

Add feedforward compensation that anticipates and cancels the Coriolis/
centripetal coupling moment (`C(M,ν_r)ν_r`) before it eats the commanded
wrench — the same mechanism a real autopilot on a real twin-azimuth vessel
would need. This is real control engineering using Vehicle C's own
already-characterized, already-cited mass/added-mass/damping matrices — not
a new model, not a new coefficient.

## Hard architectural constraints

1. **Reuse the existing Coriolis computation. Do not reimplement it.**
   `vehicle-c-plant-response-diagnostic.ts` already located and used the
   exact function/matrix assembly that produces `C(M,ν_r)ν_r` inside
   `coupledSixPlant.js` (per its report: RK4 integration, damping assembled
   in `damping.ts`). Import and call that same function. A second,
   independently-written Coriolis matrix construction is exactly the kind
   of duplicated-physics-code this project's discipline exists to prevent,
   and it would risk a subtle sign/frame mismatch against the plant's real
   internal calculation.
2. **`portable-controllers.ts` stays simulator-neutral.** Do not add a
   plant-specific (`coupled6`) import into it. `losAction()`,
   `losActionWithGains()`, `FROZEN_GAINS`, `ControllerName`, and
   `VEHICLE_C_CANDIDATE_GAINS`/`losActionCandidate()` are all unchanged by
   this task. Put the compensation in a new, clearly Vehicle-C-specific
   module (e.g. alongside `backends/node/src/vehicle-c-production.ts`, or
   wherever the Vehicle C harness currently calls `vehicleCDesiredWrench` —
   locate the right seam, don't assume).
3. **Use the frozen `LOS-PID-v2` gains (`losAction`), not
   `losActionCandidate`.** The lookahead=4 candidate was rejected per its
   pre-registered prediction and stays rejected. This task adds
   compensation on top of the *original*, unmodified gain set.
4. **No new uncited coefficients.** Every value used (`Iz=240`, added mass
   `517.937`, linear/quadratic damping) must come from the same resolved
   hydrodynamics artifact (`artifacts/capytaine/vehicle-c-parametric-
   resolved.json`) already in use — don't hardcode or re-derive numbers.

## Step 1 — Locate the seam and confirm the sign convention

Find where Vehicle C's harness currently does:
`losAction(...) → vehicleCDesiredWrench(...) → allocator`.
Confirm the exact point to insert compensation: it must happen to the
desired wrench *before* the allocator call, since the allocator has already
been shown to reproduce whatever it's given to floating-point precision —
compensation is about what gets asked for, not how it's delivered.

State explicitly, with the sign check: the equation of motion has
`- C(M,ν_r)ν_r` as an opposing term. To cancel it, the compensation added
to the desired wrench is `+ C(M,ν_r)ν_r`, evaluated at the vehicle's
current relative velocity state each timestep. Confirm this sign against
the actual convention `coupledSixPlant.js` uses — don't assume the sign
carries over correctly from the diagnostic's report without checking, since
the diagnostic was reading the term, not injecting one.

## Step 2 — Implement, surge/yaw only, report sway

Guidance only ever commands `[surge, 0, 0, 0, 0, yaw]` — it has no sway
channel. Add compensation to the **surge and yaw** components of the
desired wrench only. Compute the full `C(M,ν_r)ν_r` 6-vector (needed
anyway, since the matrix multiply isn't separable by component), but do
**not** add the sway component to the commanded wrench — sway is currently
handled entirely by the allocator's own moment-cancellation behavior, and
introducing a nonzero commanded sway is a separate architectural change
this task does not make.

Log the sway component's magnitude anyway, across all four diagnostic
seeds. If it's a small fraction of the surge/yaw compensation magnitude,
say so and move on. If it's large, flag it explicitly as an open question
rather than silently deciding either to add it or ignore it.

## Step 3 — Saturation check (new risk, not yet tested)

No allocator-capacity failure has ever occurred for Vehicle C so far —
every prior run showed `saturation_scale=1`, `degradation="none"`,
`reachable=true` throughout. Compensation adds real additional commanded
moment during turns, which is new. For all four seeds, log whether
`saturation_scale`, `degradation`, or nonzero `residual_wrench` appear for
the first time under compensation. Report this explicitly even if the
answer is "still never saturates" — that's a real, useful result either
way.

## Step 4 — Run the four diagnostic seeds with the pre-registered split prediction

Seeds: 30000, 30007, 30013, 30048. Not 30003, not the full sweep.

**Pre-registered prediction, split by mechanism, stated before running:**
- **30007**: near-full recovery expected — steady, low-velocity case, well
  suited to feedforward compensation computed from current velocity state.
- **30000, 30048**: partial improvement expected, not necessarily full
  recovery — their Coriolis cancellation is turn-transient and
  concentrated (94.9%/97.5% of opposing Coriolis moment falls in turning
  phases), and they were already shown to have large post-dynamics lag
  gaps (88.1%/82.5%) independent of Coriolis. Compensation may itself
  demand faster wrench changes exactly during those turns, which could
  interact with the existing lag problem rather than simply fixing it —
  check whether the post-dynamics gap fraction for these two goes up,
  down, or stays flat under compensation, same as was checked for the
  rejected gain candidate.
- **30013**: expected to remain a success (already fixed by the endpoint
  geometry change); confirm no regression.

Report success/fail, closest-approach, and (for 30000/30048) the
post-dynamics gap fraction, before vs. after compensation, for all four.

## Explicit prohibitions

- Do not touch `losAction`, `losActionWithGains`, `FROZEN_GAINS`,
  `ControllerName`, or anything Vehicle A's calibration reads.
- Do not re-enable or modify `losActionCandidate`/
  `VEHICLE_C_CANDIDATE_GAINS`.
- Do not add sway compensation to the commanded wrench — measure and
  report only.
- Do not touch seed 30003.
- Do not run the full 50-seed sweep.
- Do not reimplement the Coriolis matrix — import and reuse the existing
  computation from `coupledSixPlant.js`.
- If the sign convention, seam location, or reused function's interface
  doesn't match what's assumed here, stop and report the discrepancy
  rather than guessing.

## Report back with

1. Sign-convention confirmation and exact insertion point (Step 1).
2. Sway-component magnitude finding (Step 2).
3. Saturation/degradation findings, all four seeds (Step 3).
4. Per-seed before/after results and whether each part of the split
   prediction held, partly held, or failed (Step 4) — stated separately
   per seed, not averaged into one verdict.
