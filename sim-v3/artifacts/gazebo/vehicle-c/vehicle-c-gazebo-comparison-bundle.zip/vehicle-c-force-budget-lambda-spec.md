# Task: force-budget-aware Lambda for the Vehicle C sliding-mode/backstepping controller

## Diagnosis this addresses

Lambda was derived purely from timing (resonant mode, actuator delay,
sampling rate) - none of the paper's three criteria reference mass,
inertia, or force limits. On the sliding surface (s=0), the implied error
dynamics are `eta_dot_t = -Lambda * eta_t`, an exponential decay - which
means the controller's own M-term is demanding acceleration on the order
of `Lambda^2 * eta_t`. At Lambda=0.952/s and the position/heading errors
actually seen (tens of meters early in a leg), that implies force/moment
demand far beyond Vehicle C's real actuator ceiling, before the C(v) and
D(v) terms even add their own contribution - explaining the 100%
saturation across every configuration tested so far, and why tuning E/R
in the sliding-mode layer never converged (they shape how saturation is
handled, not the underlying demand that's causing it).

**Keep everything else exactly as built**: the M/C/D matrices, waypoint
target adaptation, allocator, sliding-mode structure (E/R, boundary layer,
anti-windup), and the backstepping infrastructure. Only Lambda's
derivation changes in this task.

## Step 1 — Derive a force-budget-constrained Lambda, analytically

On the sliding surface, the M-term's implied force/moment demand scales
approximately as `M * Lambda^2 * position_error` (surge/sway) and
`I_z * Lambda^2 * heading_error` (yaw). Using:
- Vehicle C's real effective mass and yaw inertia (rigid + added mass,
  same matrices already in use).
- The current force/moment ceiling (post both thrust increases: ~2681N
  surge/sway budget, ~2172 Nm yaw budget - confirm exact current values
  from the production config rather than assuming these).
- The P95 position and heading error actually observed in existing traces
  (the sliding-mode diagnostic's own E_0 measurement - [29.00m, 17.88m,
  1.845rad] - is a reasonable starting point, or pull a fresh P95 directly
  from the frozen-controller baseline traces if that's more precise).
- A reserved fraction of the budget for the M-term specifically, leaving
  headroom for C(v) and D(v) (which are correlated with the same turning
  events, per the lesson already learned from the gain-derivation task -
  don't reserve 100% of the budget for the M-term alone).

Solve for the largest Lambda (per axis, or a single scalar if the paper's
diagonal-Lambda-times-identity structure is kept) that keeps the M-term's
implied demand within the reserved budget. Show the arithmetic explicitly
- this is a real derivation, not a guess.

Take the final Lambda as the minimum of this force-budget-derived value
and the paper's original timing-derived value (0.952/s) - timing remains
a valid upper bound, force budget is now checked as an additional,
likely-binding constraint.

## Step 2 — Test empirically, don't trust the analytic derivation alone

The analytic approximation (Step 1) ignores C(v) and D(v)'s own
contribution and the correlation between all three terms during turns -
the same simplification that caused the gain-derivation task's saturation-
aware attempt to still saturate more than predicted. Run the four
diagnostic seeds (30000, 30007, 30013, 30048 - not 30003, not the full
sweep) with backstepping only first (same as the original task's staged
approach), using the new Lambda. Report saturation fraction directly - if
it's still high (say, above 20-30%), the reserved-budget fraction in Step
1 was too generous; reduce it and retry, but cap this at 2 additional
iterations total (3 attempts including the first) - this is a bounded
check, not an open-ended search.

## Step 3 — Re-run sliding mode with the settled Lambda

Once backstepping's saturation is meaningfully reduced (not necessarily
zero - some saturation during hard turns may be unavoidable given real
force limits, as established throughout this investigation), re-run the
sliding-mode controller with the same E/R tuning procedure as before
(paper's iterative method, starting E from observed steady-state error),
now built on top of the corrected Lambda rather than the timing-only one.

Report success/fail, final-leg-gated closest approach, position/heading
error mean+-SD (same format as before, for direct comparison), and
saturation fraction for all four seeds, compared against both the
original (timing-only Lambda) backstepping/sliding-mode results and the
current best PID-based configuration on record.

## Explicit prohibitions

- Do not modify the M/C/D matrices, waypoint adaptation, allocator, or
  sliding-mode E/R tuning procedure itself - only Lambda's derivation.
- Do not touch `FROZEN_GAINS`, `ControllerName`, `losAction()`, or
  anything Vehicle A's path reads.
- Do not touch seed 30003 or run the full sweep.
- Cap Step 2's empirical adjustment at 3 total attempts - if saturation is
  still high after 3, stop and report that force-budget-constrained Lambda
  alone isn't sufficient, rather than continuing to iterate indefinitely.
- Do not implement the paper's output low-pass filter in this task -
  still held as a fallback for a later task if needed.

## Report back with

1. The full Step 1 derivation with actual numbers, and the selected
   Lambda (force-budget value vs. timing bound, whichever is smaller).
2. Step 2's empirical check(s) - saturation fraction per attempt, and
   which attempt was accepted.
3. Step 3's sliding-mode results, compared against both the original
   timing-only-Lambda results and the current best PID configuration.
