# Task: open-loop fixed-input trajectory comparison, bcod-sim vs Gazebo, with quantified error

## What this is

No controller, no closed-loop bridge. Give both simulators the identical,
pre-scripted pod thrust/azimuth commands (open-loop), log both resulting
trajectories at full resolution, and quantify the divergence between them
over time. This reuses the existing open-loop infrastructure
(`generate_vehicle_c_reference.ts`, `run_gazebo_vehicle_c_trace.py`), now
re-run with the corrected SDF thrust cap (1340.506N/670.253N per pod,
already fixed in `model.sdf`) instead of the stale 500N cap it originally
validated against.

## Step 1 — Re-run the existing fixed-input scenarios

Reuse the four existing scenarios already defined in
`generate_vehicle_c_reference.ts` (`straight-ahead`, `pure-lateral`,
`rotation-in-place`, `allocation-chirp`) - don't invent new ones, these
already give a reasonable spread of pure-surge, pure-sway, pure-yaw, and
mixed/changing inputs. Re-run both the bcod-sim reference and the Gazebo
trace for all four, now against the corrected SDF.

## Step 2 — Log at full resolution for both simulators

Same requirement as the closed-loop task: no downsampling, matched
0.05s time base, north/east/heading (task frame, both already converted
via the existing `gazeboOdomToTask` conversion) at every step for both
simulators, plus the commanded pod thrust/azimuth (which is identical by
construction here, but log it anyway for the record) and each simulator's
actual delivered pod thrust/azimuth (they may differ from commanded due to
each simulator's own actuator dynamics).

## Step 3 — Quantify error, per scenario

For each of the four scenarios, compute and report:
- Horizontal position error (bcod-sim vs Gazebo) at every timestep - report
  as a full time series, not just a summary, so it can be plotted.
- Heading error at every timestep, same treatment.
- Summary statistics per scenario: mean, P95, max horizontal error; mean,
  P95, max heading error; final-timestep error.
- Whether divergence grows steadily over the run or appears as a sharp
  jump at a specific point (note the timestep if there's a jump).

## Step 4 — Output one figure-ready artifact

Same paired-artifact convention as before: one JSON file containing all
four scenarios, each with both simulators' full time series as sibling
arrays, plus the per-scenario error time series and summary statistics,
plus scenario metadata (the actual commanded input schedule for each) and
provenance (SDF/controller-irrelevant here, but note the SDF thrust-cap
correction and its date/task in provenance so it's traceable). Place in
`artifacts/gazebo/vehicle-c/`.

Do not generate a plot image yourself - just get the data into one clean,
complete, well-structured file. Paste the resulting summary statistics and
confirm the artifact path back in this conversation; the actual figure
will be made from that data separately.

## Explicit prohibitions

- No controller involved - this is fixed-input open-loop only, reusing
  the original scenario definitions unchanged.
- Do not modify the SDF, thrust cap, or any physics parameters - use what
  was already corrected in the prior task.
- Do not downsample or summarize away the per-timestep data - full
  resolution only.

## Report back with

1. Confirmation all four scenarios ran successfully in both simulators.
2. The artifact path.
3. The summary error statistics per scenario (mean/P95/max, both position
   and heading), and a note on any sharp-jump points found.
