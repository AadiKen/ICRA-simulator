# Task: closed-loop Vehicle C comparison, bcod-sim vs Gazebo Harmonic

## What exists already — reuse, don't rebuild

The open-loop check (`validation/gazebo-vehicles/{generate_vehicle_c_
reference,compare_vehicle_c,run_gazebo_vehicle_c_trace}`) already validated:
SDF loads cleanly (`gz_sdf_check`, `headless_world_load`,
`inertia_triangle_inequality` all passed), the frame mapping (bcod body
NED/FRD positive azimuth = negative Gazebo FLU joint angle), and the
allocator/kinematics under fixed pod commands. Reuse all of this - the SDF,
`vehicle-c-parameter-map.json`, the frame-mapping convention, and the
trajectory-comparison logic in `compare_vehicle_c.ts` (horizontal/yaw diff
against a converted reference). Do not modify the SDF or re-derive the
frame mapping.

**The gap**: the existing check only ever fed Gazebo a pre-scripted,
open-loop command schedule (`generate_vehicle_c_reference.ts`'s
`cases` functions). This task closes the loop: the backstepping controller
must compute new pod commands from Gazebo's own live state each step, the
same way it already drives bcod-sim's `sim.step()` loop.

**Reuse the actual controller code - do not reimplement the control law
in Python or anywhere else.** The controller
(`vehicle-c-sliding-mode-controller.ts`'s backstepping mode, adopted
configuration: Lambda=0.9523809524, Kp=[485.995033]x3,
Kd=[849.689997]x3), the allocator (`allocatePlanarAzimuthMinimumNorm`),
and the M/C/D matrices all stay exactly as already validated.

## Step 1 — Build a step-synchronized bridge

Gazebo is currently driven via `run_gazebo_vehicle_c_trace.py`. Determine
how it communicates with the simulation (ROS2/gz topics, or another
mechanism - check the existing script rather than assuming) and build a
step-synchronized loop: read Gazebo's current odometry, convert to the
task frame (reuse `gazeboOdomToTask`, already implemented), pass that
state into the same controller code used for bcod-sim, get the resulting
pod thrust/azimuth commands, send them to Gazebo, advance one step, repeat.

Since the controller is TypeScript and Gazebo's runner is Python, use a
thin bridge (e.g. the Python runner calls out to a small Node process per
step, or a lightweight local RPC) rather than porting the controller logic
into Python - the goal is one control law, not two independently written
ones that could silently diverge.

Confirm the step timing matches (0.05s / 20Hz, same as bcod-sim's RK4
step) so the comparison is apples-to-apples in time as well as space.

## Step 2 — Run one scenario closed-loop in both simulators

Use seed 30013's route (already characterized in bcod-sim: 1.918m closest
approach, success, under the exact adopted backstepping configuration) as
the first closed-loop test case - a known, already-understood scenario
rather than inventing a new one. Run it end-to-end in bcod-sim (already
straightforward) and, via the Step 1 bridge, in Gazebo.

State explicitly, before reporting results: Gazebo's Vehicle C model has
no Coriolis coupling or added-mass dynamics (`no pod-hull interaction or
angle-dependent thrust interaction`, per the existing check's own
`claim_limit`). The controller's C(v) compensation term is tuned for
bcod-sim's own coupling and will be present but compensating for an effect
Gazebo doesn't simulate. This is not a matched-physics test - it's a test
of whether the same validated control law produces comparable navigation
outcomes on a simpler model. Say this plainly in the report, don't let the
comparison numbers imply more than they show.

## Step 3 — Compare trajectories and outcomes

Using the same diff approach as `compare_vehicle_c.ts` (horizontal
position error, yaw error over time between the two runs), report:
- Trajectory divergence over time (does it stay small, grow steadily, or
  diverge sharply at a particular point - e.g. the endpoint-capture
  transition, which is a completely different mechanism now than pure
  line-following was).
- Final outcome in each simulator: does Gazebo's simpler model also reach
  the goal, and at what closest approach - compare directly to bcod-sim's
  1.918m for this seed.
- Saturation behavior in each (Gazebo's simpler dynamics may saturate the
  allocator less, since there's no Coriolis moment competing for the same
  budget - report whether that's observed).

## Explicit prohibitions

- Do not modify the controller, gains, M/C/D, or allocator.
- Do not modify the Gazebo SDF or frame mapping.
- Do not reimplement the control law in Python or any second language -
  bridge to the existing TypeScript implementation.
- Do not run additional seeds beyond 30013 in this task - one scenario
  first, to confirm the bridge and methodology work before expanding.

## Report back with

1. How the step-synchronized bridge works (Step 1) - what mechanism, and
   confirmation of matched timestep.
2. The explicit physics-mismatch caveat, stated up front (Step 2).
3. The trajectory comparison and final-outcome comparison (Step 3).
