# Task: per-axis force-budget-aware Kp/Kd for the backstepping controller

## Diagnosis this addresses (confirm before proceeding)

The prior task's saturation trace shows Kp demanding ~14,095N on the north
axis against a 2,681N ceiling (5.3x over), ~8,690N on east (3.2x over),
but only ~896 Nm on yaw against a 2,172 Nm ceiling (well within budget).
Lambda reduction couldn't fix this because Lambda only scales the M-term,
not the `-J^T * Kp * eta_t` term directly.

**First, confirm the suspected cause**: report what Kp value(s) are
currently used in the backstepping/sliding-mode controller's `Kp * eta_t`
term, and whether the north/east position-error gain is the same numeric
value as `kp=485.995` from the earlier saturation-aware LOS-PID gain
derivation (a heading-error gain, in Nm/rad, from a different controller).
If so, that confirms the mechanism: a gain sized for multiplying radians
(max ~2.2 rad heading error) was applied unchanged to meters (max ~29m
position error), producing a demand roughly an order of magnitude too
large. State plainly whether this is confirmed or whether the actual
cause is something else - don't assume the diagnosis is right without
checking.

## Step 1 — Derive Kp and Kd separately per axis, in their real units

Unlike Lambda (a single decay-rate constant reasonably shared across
axes), Kp and Kd here multiply physically different quantities - north/
east position error in meters, heading error in radians - and must be
sized independently per axis, not as one scalar.

For each axis (north, east, heading), using the same force-budget
methodology already validated for Lambda:
- The relevant force/moment ceiling (2681N for north/east, 2172 Nm for
  yaw - confirm current exact values).
- The P95 error magnitude for that axis from existing traces (reuse
  [29.003, 17.882, 1.845] if still representative, or pull fresh P95 data
  if more precise numbers are available).
- A reserved budget fraction for the Kp term specifically, leaving
  headroom for the M-term (now correctly scaled via the settled Lambda),
  C(v), D(v), and Kd - state the reasoning for the split, same as before.

Derive `Kp_axis = (reserved_budget_axis) / (P95_error_axis)` for each
axis. Derive `Kd_axis` to achieve a reasonable damping ratio given the
now-correct Kp_axis and the axis's real effective mass/inertia (323.459kg
surge, 904.051kg sway, 757.937 kg-m2 yaw) - report the resulting damping
ratio per axis, not just the gain value, same rigor as the original
inertia-scaled-gains task.

## Step 2 — Test empirically, same bounded-iteration approach as before

Run the four diagnostic seeds (30000, 30007, 30013, 30048 - not 30003, not
the full sweep) with backstepping only, using the corrected per-axis Kp/Kd
and the already-settled force-budget Lambda from the prior task. Report
saturation fraction per axis (not just an aggregate), since the fix is
axis-specific and the result should be checked that way. If saturation is
still high on a specific axis, adjust that axis's reserved fraction and
retry - cap at 3 total attempts, same discipline as the Lambda task.

## Step 3 — Re-run sliding mode once backstepping saturation is reduced

Same as the prior task's Step 3: once backstepping's saturation is
meaningfully reduced, re-run sliding mode with the paper's iterative E/R
tuning procedure on top of the now-correctly-scaled Kp/Kd/Lambda. Report
success/fail, final-leg-gated closest approach, position/heading error
mean+-SD, and per-axis saturation for all four seeds, compared against the
current best PID-based configuration and the prior (Lambda-only-fixed)
backstepping/sliding-mode attempt.

## Explicit prohibitions

- Do not modify the M/C/D matrices, waypoint adaptation, allocator, or
  the settled Lambda value from the prior task.
- Do not touch `FROZEN_GAINS`, `ControllerName`, `losAction()`, or
  anything Vehicle A's path reads.
- Do not touch seed 30003 or run the full sweep.
- Cap Step 2's empirical adjustment at 3 total attempts.
- Do not implement the paper's output low-pass filter in this task.

## Report back with

1. Confirmation (or correction) of the diagnosed cause.
2. Full per-axis Kp/Kd derivation with actual numbers and resulting
   damping ratios.
3. Step 2's per-axis saturation results across attempts.
4. Step 3's sliding-mode results, compared against both the current best
   PID configuration and the prior backstepping/sliding-mode attempt.
