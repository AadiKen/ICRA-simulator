# Addendum: logging requirements for figure generation

Append this to the closed-loop comparison task. The goal is a single,
complete artifact that can be loaded directly into a plotting tool
afterward - no need to regenerate or re-run anything to make a figure
later.

## Log at every physics timestep, both simulators, matched time base

For bcod-sim and Gazebo separately, at every 0.05s step (not downsampled):
- `time_s`
- `north_m`, `east_m` (task frame, both already converted to the same
  frame via `gazeboOdomToTask` for Gazebo - confirm bcod-sim's own output
  uses the identical frame/origin convention so the two overlay directly
  without a second conversion step at plot time)
- `heading_rad`
- `distance_to_goal_m`
- `surge_mps`, `yaw_rate_rad_s`
- commanded pod thrust/azimuth for both pods (port, starboard)
- allocator saturation state (`saturation_scale`, `degradation`) if
  available for both simulators - note explicitly if Gazebo's simpler
  model doesn't expose an equivalent field, rather than leaving it blank
  without explanation

## Also record, once per run (not per-timestep)

- The scenario identity (seed 30013, route/waypoint coordinates, initial
  position/heading) so the figure can plot the actual route and start/goal
  markers, not just the two trajectories in isolation.
- Controller configuration (the adopted backstepping gains) and a note on
  the physics-mismatch caveat, so it can be reproduced as a figure caption
  or footnote without digging back through this task's report.
- `schema_version`, provenance (source file hashes for the controller,
  SDF, and parameter map used), matching this project's existing artifact
  conventions.

## Output as one paired artifact

Write bcod-sim's and Gazebo's time series into a single JSON artifact with
both trajectories as sibling arrays under the same top-level scenario
metadata (not two separate files that need to be manually matched up by
timestamp later). Place it in `artifacts/gazebo/vehicle-c/` following the
existing directory convention.

## Explicit requirement

Do not summarize, downsample, or truncate the per-timestep logs for either
simulator to save space - the full-resolution trajectories are what makes
the eventual figure possible. Summary statistics (mean/P95 divergence
etc.) are additional, not a replacement for the raw series.
