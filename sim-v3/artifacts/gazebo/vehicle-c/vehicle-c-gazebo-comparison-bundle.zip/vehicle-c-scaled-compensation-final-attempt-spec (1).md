# Task: scaled Coriolis compensation - single attempt, pre-committed stop condition

## This is the last dispatch on this line of investigation

One scale value is tested. If it doesn't clearly work, this gets written up
as a characterized partial result (guidance bug fixed - benefits Vehicle A;
allocator exonerated; actuator lag characterized; Coriolis coupling
identified and compensated; remaining gap attributed to allocator
saturation under combined compensation-plus-turn-transient loading) and
Vehicle C work on this specific approach stops. No further scale values, no
new mechanisms, no additional dispatches on this thread regardless of how
close the result looks. State this explicitly in your report so the
decision is visible, not just implied by silence.

## What changes

In `backends/node/src/vehicle-c-coriolis-feedforward.ts`, apply a single
scale factor to the compensation term before it's added to the desired
wrench:

```
tau_comp = 0.5 * C(M, nu_r) * nu_r    // was: tau_comp = C(M, nu_r) * nu_r
```

Scale factor 0.5 is the test value - a principled midpoint between no
compensation (known: three timeouts, one already-invalid "success") and
full compensation (known: closer approaches on 3/4 seeds, but new
saturation down to 40.6% capacity and degraded allocation on up to 12.83%
of timesteps). Everything else - insertion point, sign, surge/yaw-only
scope, sway measured-not-commanded, reused `coriolisFromMass6()` - stays
exactly as implemented in the prior task. Do not touch `losAction`,
`FROZEN_GAINS`, the rejected candidate gains, or shared code.

## Correction to carry forward

The prior task's baseline for seed 30013 was mis-specified in my
instruction - I claimed it would "remain a success," which was wrong; that
success was only ever observed under the rejected lookahead=4 candidate.
The valid baseline is frozen `LOS-PID-v2` gains with the endpoint-geometry
fix only, which times out at 3.459 m closest approach. Compare 30013's
scaled-compensation result against that 3.459 m baseline, not against the
invalid "success" reference.

## Run the four seeds, report against the pre-committed gate

Seeds: 30000, 30007, 30013, 30048. Not 30003, not the full sweep.

For each: closest-approach distance and success/fail, post-dynamics gap
fraction, and allocator saturation scale / degraded-fraction - same metrics
as the full-compensation run, so it's a direct three-way comparison
(baseline / full compensation / scaled compensation).

**Pre-committed adopt/stop gate, stated before running:**
- **Adopt** (keep this change, report it as the working configuration) if
  at least 2 of the 4 seeds reach terminal success (<=2 m), OR if degraded-
  allocation fraction drops to roughly 2% or below on all four seeds while
  retaining at least half of full compensation's average closest-approach
  improvement over baseline.
- **Stop** (anything short of that) - report the numbers, state plainly
  that the gate wasn't met, and do not propose or attempt a different scale
  value.

## Explicit prohibitions

- Exactly one scale value (0.5). Do not sweep, search, or try a second
  value even if 0.5 looks close to the gate.
- Do not touch shared guidance, rejected candidate gains, physics, or
  allocator code.
- Do not touch seed 30003.
- Do not run the full 50-seed sweep.
- Do not add sway compensation.

## Report back with

1. The three-way comparison table (baseline / full / scaled) for all four
   seeds.
2. Explicit adopt-or-stop verdict against the pre-committed gate, stated
   plainly, not softened either direction.
3. If "stop": confirmation that no further scale value was attempted.
