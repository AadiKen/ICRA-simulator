# Task: final sliding-mode attempt — E derived from backstepping's own tracking error

## This is the last attempt on sliding mode

If this doesn't clearly beat backstepping, backstepping (Lambda=0.952381,
Kp=[485.995,485.995,485.995], Kd=[849.690,849.690,849.690], as already
implemented and confirmed) is adopted as Vehicle C's working configuration
and this line of investigation ends. State the adopt/stop verdict
explicitly in the final report.

## Why E was wrong before

The prior E_0 ([29.003, 17.882, 1.845]) was measured from the old,
discarded PID baseline's tail-end tracking error - tens of meters. The
paper derived E from their *own already-working* controller's steady-state
error, which was much smaller. A boundary layer that wide barely
distinguishes "far from target" from "close to target," which plausibly
explains why every R value tried still saturated 100% without converging.

## Step 1 — Derive E from backstepping's own achieved error

Using the confirmed backstepping results (seeds 30000 and 30013 succeed;
30007 and 30048 time out but get close - 3.145m and 2.253m), extract the
tracking error basis the paper's method actually calls for: the error
during the portion of each trajectory where the vehicle is actively
converging on / holding near the target, not the wide-open transient at
the start of a leg. For the two successful seeds, use the final segment
before success (same "final N seconds" approach as before, but choose N
based on when the error trace actually settles, not an arbitrary reused
value - report what you observe and why the chosen window is
representative). For the two seeds that time out but get close, decide
and state whether to include their near-closest-approach segment too, or
exclude them since they never truly reach steady state - make this call
explicitly rather than silently.

Report the resulting E per axis, and compare it directly to the old,
discarded E_0 - the ratio between them should be large if the diagnosis is
right.

## Step 2 — Re-run the R/E procedure, bounded

Same iterative procedure as before (increase R until steady state;
adjust E only if saturation or error problems persist), but capped this
time at 6 total tuning iterations across R and E combined (not R alone) -
if no configuration reaches at least 3 of 4 seeds succeeding, or matching
backstepping's per-seed closest-approach distances with meaningfully
reduced saturation, stop at the cap rather than continuing.

## Step 3 — Final comparison and verdict

Report success/fail, final-leg-gated closest approach, position/heading
error, and saturation for all four seeds under the best sliding-mode
iteration, compared directly against backstepping's own results
(1.955m/success, 3.145m/timeout, 1.918m/success, 2.253m/timeout).

State the adopt/stop verdict explicitly:
- **Adopt sliding mode** only if it clearly improves on backstepping (more
  successes, or comparable/better distances with less saturation) on this
  four-seed set.
- **Adopt backstepping** (stop sliding-mode work) if sliding mode doesn't
  clearly improve on it - in which case say so plainly, and confirm
  backstepping's configuration is what should carry forward as Vehicle C's
  controller.

## Explicit prohibitions

- Do not modify Lambda, Kp, or Kd from the confirmed backstepping values
  in this task - only E and R are being tuned for the sliding-mode layer
  on top of them.
- Do not modify M/C/D, the allocator, or waypoint logic.
- Do not touch `FROZEN_GAINS`, `ControllerName`, `losAction()`, or
  anything Vehicle A's path reads.
- Do not touch seed 30003 or run the full sweep.
- Do not add the paper's output low-pass filter.
- Hard cap at 6 tuning iterations - stop and report at the cap regardless
  of where results stand.

## Report back with

1. The corrected E derivation and its ratio to the old E_0 (Step 1).
2. The tuning trajectory across all iterations attempted (Step 2).
3. The final four-seed comparison and the explicit adopt/stop verdict
   (Step 3).
