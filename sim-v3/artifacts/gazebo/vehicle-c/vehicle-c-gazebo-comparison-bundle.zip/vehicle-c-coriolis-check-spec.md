# Task: check Coriolis cancellation fraction on seeds 30000 and 30048

## Why

Seed 30007's stall is explained: 97.46% of delivered yaw moment is cancelled
by Coriolis coupling (`C(M,ν)ν` in the coupled6 plant), not damping or lag.
Seeds 30000 and 30048 were already shown to have large post-dynamics
wrench-tracking gaps (88.1% and 82.5% noticeable-gap fractions, from the
earlier wrench-path diagnostic), which looked lag-dominated. This task
checks whether Coriolis cancellation is also a major factor for these two,
using the same decomposition already built for 30007. The result decides
between two different next steps (Coriolis feedforward compensation vs.
documenting as a scoped limitation) — get the numbers first, don't guess.

**Scope: seeds 30000 and 30048 only.** Not 30007 (already done), not 30013,
not 30003, not the full sweep.

## Reuse existing instrumentation — no new diagnostic architecture

You already have, from the two prior diagnostics:
- The wrench-path logging (`desired_wrench`, `achieved_wrench`,
  `lastFullWrench`, pre-lag/post-dynamics gaps) from
  `vehicle-c-wrench-path-diagnostic.ts`.
- The plant equation-of-motion decomposition from
  `vehicle-c-plant-response-diagnostic.ts` — specifically however it
  isolated `Coriolis coupling` and `hydrodynamic damping` as separate terms
  from `-C(M,ν_r)ν_r` and `-B_lin ν_r - B_quad|ν_r|ν_r` in the RK4 state
  derivative at `coupledSixPlant.js`.

Combine them: for seeds 30000 and 30048, log the same
`delivered_yaw_moment`, `coriolis_moment`, `damping_moment`,
`net_yaw_wrench` breakdown that was reported for 30007 at its closest
approach — but across the full trace, not just one instant, since these two
seeds' failures aren't localized to a single closest-approach moment the way
30007's summary was framed.

## Step 1 — Per-timestep decomposition

For each of 30000 and 30048, log at every timestep:
- `t_s`
- `delivered_yaw_moment_nm` (post-lag, from `lastFullWrench`)
- `coriolis_moment_nm` (the `-C(M,ν_r)ν_r` yaw component)
- `damping_moment_nm` (the `-B_lin ν_r - B_quad|ν_r|ν_r` yaw component)
- `net_yaw_wrench_nm` (delivered + coriolis + damping, signed consistently
  with how 30007's report combined them)
- `observed_yaw_accel` (same finite-differencing method as the 30007 task)

## Step 2 — Report, per seed

- Mean and 95th-percentile fraction of `delivered_yaw_moment` cancelled by
  `coriolis_moment` alone, and separately by `damping_moment` alone —
  report these as two distinct percentages, not combined, so it's clear
  which mechanism dominates.
- How that compares to the already-known post-dynamics (lag) gap fraction
  for the same seed (88.1% for 30000, 82.5% for 30048) — is Coriolis
  cancellation additive on top of the lag problem, or is one mechanism
  clearly dominant and the other minor.
- Whether the Coriolis-cancellation fraction is roughly constant through
  the episode or concentrated in specific phases (e.g. during the turns
  toward the goal, which is when yaw rate and surge velocity are both
  large and cross-coupling is strongest).

## Step 3 — Summary across all three characterized seeds

Produce one small table: seed, dominant mechanism (Coriolis / lag-dynamics /
mixed), approximate magnitude of each. Include 30007's already-reported
97.46%/negligible-damping numbers as the third row for comparison — don't
rerun 30007, just restate its existing numbers here for the summary table.

## Explicit prohibitions

- Seeds 30000 and 30048 only for new instrumentation; 30007's existing
  numbers are restated, not rerun; 30013 and 30003 are out of scope.
- Read-only. No gain, physics, or allocator changes.
- No full sweep.
- No Coriolis compensation implementation in this task — this is
  measurement only, to inform a decision that hasn't been made yet.

## Report back with

1. Per-seed Coriolis-fraction and damping-fraction numbers (Step 2).
2. Whether cancellation is uniform or phase-concentrated (Step 2).
3. The three-seed summary table (Step 3).
