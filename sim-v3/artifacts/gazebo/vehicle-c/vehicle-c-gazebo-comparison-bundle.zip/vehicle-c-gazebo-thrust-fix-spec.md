# Task: fix the Gazebo SDF thrust cap, re-run the closed-loop comparison

## The confound

The seed-30013 closed-loop run showed Gazebo's SDF capping each pod at
500N, while the controller (gains, Lambda, and allocator budget) was
tuned and validated against the current production rating of 1340.506N
forward / 670.253N reverse per pod. Gazebo had well under 37% of the
thrust authority the controller assumes exists. This plausibly explains
most or all of the observed failure (immediate divergence at 1.3s,
saturation at every step, waypoint transitions 4-5x slower) independent of
any missing Coriolis/added-mass physics - the two effects need to be
separated, not reported together as one undifferentiated "Gazebo is
different" finding.

## Step 1 — Update the SDF's pod thrust limits

Update `gazebo/models/vehicle-c-azimuth/model.sdf` (or wherever the 500N
cap is actually set - confirm the exact location, don't assume) to match
the current production values: 1340.506N forward, 670.253N reverse, per
pod, preserving the 2:1 ratio. Re-run whatever existing SDF validation
checks were used in the original open-loop check (`gz_sdf_check`,
`headless_world_load`, `inertia_triangle_inequality`) to confirm the
change doesn't break anything.

State explicitly whether this thrust value is documented/cited anywhere
in the SDF or its accompanying parameter map, and add a citation comment
pointing back to `vehicle-c-production.ts`'s derivation if one doesn't
already exist - same discipline as every other actuator constant in this
project.

## Step 2 — Re-run the identical seed-30013 closed-loop scenario

Same bridge, same controller, same allocator, same everything except the
corrected SDF thrust cap. Same full-resolution paired-artifact logging as
the first run (all fields, no downsampling, matched 0.05s time base,
scenario/controller/provenance metadata) - write it as a new artifact
(`closed-loop-comparison-30013-thrust-corrected.json` or similar), don't
overwrite the original, so both remain available for comparison.

## Step 3 — Report the corrected comparison, and what changed

Report bcod-sim vs. Gazebo results the same way as before (success/fail,
closest approach, divergence-over-time, saturation, waypoint-transition
timing), and explicitly compare against the original (thrust-mismatched)
run: does correcting the thrust cap close most of the gap, some of it, or
none of it? That answer is what actually tells you how much of the
original divergence was the actuator-authority confound versus the
missing-physics caveat that's still genuinely true regardless (Gazebo
still won't model Coriolis/added-mass/pod-interaction even with the
corrected thrust cap - restate that caveat plainly in this report too,
since it remains real).

## Explicit prohibitions

- Do not modify the controller, gains, allocator, or bridge logic - only
  the SDF's thrust cap changes.
- Do not run additional seeds beyond 30013 in this task.
- Do not delete or overwrite the original (thrust-mismatched) artifact -
  both results, compared side by side, are the actual finding here.

## Report back with

1. Where the thrust cap was set in the SDF, and confirmation of the fix
   plus a citation comment (Step 1).
2. The corrected closed-loop run's full results (Step 2).
3. A direct before/after comparison isolating how much of the original
   divergence was the thrust confound vs. the remaining physics-fidelity
   gap (Step 3).
