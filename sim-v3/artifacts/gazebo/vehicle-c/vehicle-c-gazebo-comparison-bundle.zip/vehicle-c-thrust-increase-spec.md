# Task: increase Vehicle C per-pod thrust rating, test against the four diagnostic seeds

## Context (why this is a legitimate design change, not a fudge)

Vehicle C has no locked real-world reference vessel — its own validation-
scoping document records `same_vessel_target: absent`, `marin_target:
absent`. Its standing claim is allocation/composability demonstrated,
dynamics not independently validated. Changing its thruster spec doesn't
invalidate any citation, because there isn't one constraining the hull or
actuators. That said, the new rating still needs to be a physically
plausible thruster spec, not an arbitrary number chosen purely to pass the
diagnostic seeds — see Step 2.

**Isolate one variable.** Pod position (`±0.81 m`), actuator dynamics
(0.35 s thrust lag, 30 deg/s azimuth slew), hull geometry, and the
controller (frozen `LOS-PID-v2` + geometry fix + full-scale Coriolis
compensation) all stay exactly as they are. Only per-pod thrust rating
changes in this task.

## Step 1 — Derive the required thrust rating from existing data, don't guess

Using the full-compensation four-seed trace
(`artifacts/rl-campaign/vehicle-c-coriolis-compensation-four-seed.json`),
compute, per seed, the full distribution (not just the minimum) of
`saturation_scale` during timesteps where saturation was active. Report
mean, median, P95, and min for each of the four seeds.

From that distribution, propose a thrust multiplier: enough to keep, say,
the 95th-percentile saturation event within the allocator's authority
(`saturation_scale >= ~0.95`), rather than sizing to the single worst
instant across the whole trace (which risks large over-provisioning for a
rare spike). State the exact percentile-based reasoning and the resulting
multiplier explicitly — this is a judgment call with a real tradeoff
(undersizing leaves residual saturation, oversizing risks looking
untethered from the actual deficit), so show the numbers, don't just assert
a factor.

Apply the same multiplier to both `maxForwardThrust` (currently 500 N) and
`maxReverseThrust` (currently 250 N) per pod, preserving their current
2:1 ratio, unless you find a specific reason in the trace data that the
forward/reverse imbalance itself needs different treatment — if so, report
that rather than silently deciding.

## Step 2 — Physical plausibility check

Before applying the new rating, check whether it falls within the range of
real, commercially documented azimuth thrusters for USVs in Vehicle C's
size/mass class (3.5 m, 313.5 kg). Cite what you find. If the computed
multiplier lands within a documented product's real specs, note that
explicitly — it strengthens the design's defensibility. If it exceeds
anything documented for this vehicle class, report that plainly as a
limitation of this redesign rather than proceeding silently; state whether
proceeding anyway is still defensible (e.g. a purpose-built research
vehicle rather than an off-the-shelf product) or whether it's a sign the
thrust-only lever isn't sufficient and the moment-arm/hull redesign is
needed instead.

## Step 3 — Apply the change and fix the stale derived constant

Update `buildVehicleCProductionConfiguration()`'s `maxThrust` and the
per-effector `maxForwardThrust`/`maxReverseThrust` in
`backends/node/src/vehicle-c-production.ts` (and
`vehicle-c-parameter-map.json` if it's meant to stay in sync with the
production config — confirm which file is the source of truth).

Also update `VEHICLE_WRENCH_LIMITS["vehicle-c-azimuth"]` in
`portable-controllers.ts` — its current `{surge_n: 1000, yaw_nm: 810}` was
derived as `2 x 500N` and `2 x 500N x 0.81m` from the old thrust rating,
with no comment explaining that derivation (a real gap, flagged
previously). Recompute it from the new rating using the same derivation,
and this time add a comment stating the formula and citing this task, so
it doesn't go undocumented again.

## Step 4 — Regression and re-run

Run whatever existing Vehicle C allocation/production unit tests already
cover thrust limits and mass/damping consistency (the prior tasks
mentioned these passing — locate and rerun them, don't assume they still
pass silently after a spec change).

Then run the four diagnostic seeds (30000, 30007, 30013, 30048 — not
30003, not the full sweep) with the new thrust rating, same controller
configuration as the full-compensation run. Report, per seed:
success/fail, closest-approach distance, `saturation_scale`/degraded-
fraction (confirm whether saturation actually clears as predicted), and
comparison against the full-compensation baseline numbers already on
record.

## Explicit prohibitions

- Do not change pod position, hull geometry, actuator lag, or azimuth slew
  rate.
- Do not change the controller, gains, or compensation scale.
- Do not touch seed 30003 or run the full sweep.
- Do not rerun the terminal-radius calibration in this task — that's a
  separate follow-up if this changes the picture enough to warrant it.
- If the derived multiplier and the plausibility check in Step 2 conflict
  sharply (data says you need far more than any real comparable thruster
  provides), stop and report that rather than picking a number that
  satisfies neither honestly.

## Report back with

1. Per-seed saturation-scale distribution and the derived multiplier
   (Step 1).
2. Plausibility-check finding, with citation if found (Step 2).
3. Confirmation of what was changed and where (Step 3).
4. Regression test results and the four-seed re-run, compared to the
   full-compensation baseline (Step 4).
