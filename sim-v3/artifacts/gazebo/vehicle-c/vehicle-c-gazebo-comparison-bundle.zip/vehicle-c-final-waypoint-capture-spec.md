# Task: fix final-waypoint capture in shared LOS-PID-v2 guidance

## Context (do not relitigate)

`losAction()` in `sim-v3/validation/rl-campaign/ports/portable-controllers.ts` is
the single shared guidance implementation used by every vehicle (A, B, C). It
already computes along-track progress (`along`) but never uses it — desired
heading is always computed against the leg's *infinite* line extension. Once a
vehicle passes the along-track position of the goal (`along >= length`),
cross-track error against that infinite line has nothing to do with distance
to the actual point, so the vehicle keeps flying the line's bearing instead of
turning back. This is the confirmed cause of Vehicle C seed 30013 passing
~3.70 m beside the final waypoint (success requires 2 m) and continuing past
it rather than recapturing.

This is a **guidance bug fix**, not a tuning change, and it is **shared with
Vehicle A** — do not scope it as Vehicle-C-only.

## Step 1 — Apply this exact patch

File: `sim-v3/validation/rl-campaign/ports/portable-controllers.ts`

Replace the file's full contents with:

```ts
export type NavigationState={north_m:number;east_m:number;heading_rad:number;surge_mps:number;yaw_rate_rad_s:number};
export type ControllerName="LOS-PID-v2"|"LOS-SPEEDCAP-v2";
export const FROZEN_GAINS:Record<ControllerName,{lookahead:number;kp:number;kd:number;speed:number}>={
  "LOS-PID-v2":{lookahead:8,kp:100,kd:35,speed:1},
  "LOS-SPEEDCAP-v2":{lookahead:4,kp:100,kd:35,speed:1}
};
const clamp=(value:number,min:number,max:number)=>Math.min(max,Math.max(min,value));
const wrap=(angle:number)=>Math.atan2(Math.sin(angle),Math.cos(angle));

/** Shared, simulator-neutral guidance and control implementation. Adapters only map its wrench. */
export function losAction(name:ControllerName,state:NavigationState,legStart:[number,number],goal:[number,number]):[number,number]{
  const gains=FROZEN_GAINS[name],dn=goal[0]-legStart[0],de=goal[1]-legStart[1],length=Math.hypot(dn,de),cn=dn/length,ce=de/length;
  const along=(state.north_m-legStart[0])*cn+(state.east_m-legStart[1])*ce;
  const cross=-ce*(state.north_m-legStart[0])+cn*(state.east_m-legStart[1]);
  const dNorth=goal[0]-state.north_m,dEast=goal[1]-state.east_m,distance=Math.hypot(dNorth,dEast);
  const desired=along>=length
    ? Math.atan2(dEast,dNorth)                              // past the endpoint: home directly on the point
    : Math.atan2(ce,cn)-Math.atan2(cross,gains.lookahead);   // on the segment: unchanged LOS line-following
  const headingError=wrap(desired-state.heading_rad);
  let speed=gains.speed;
  if(name==="LOS-SPEEDCAP-v2") speed=Math.min(speed,Math.sqrt(Math.max(0,.8*distance)),speed*Math.max(.25,Math.cos(Math.min(Math.PI/2,Math.abs(headingError)))));
  // [surge force N, yaw moment Nm], exactly as the frozen calibration implementation.
  return [clamp(100*(speed-state.surge_mps),-150,150),clamp(gains.kp*headingError-gains.kd*state.yaw_rate_rad_s,-100,100)];
}

export function vehicleAWrenchToActuators([surge,yaw]:[number,number]):[number,number,number,number]{
  // Vehicle A's 4-vector reserves unused dimensions at zero; this is the common portable action contract.
  return [clamp((surge-yaw)/150,-1,1),clamp((surge+yaw)/150,-1,1),0,0];
}
```

The only functional change is the `desired` branch. Gains, actuator mapping,
and exports are byte-identical to before.

## Step 2 — Locate and verify the local Vehicle C acceptance harness

The harness that produced seeds 30013/30007/30003 is local/uncommitted (not
in the pushed repo as of this task). Before running anything:

1. Find it and confirm it imports `losAction` from
   `validation/rl-campaign/ports/portable-controllers.ts` rather than a local
   copy of the guidance math. If it has its own duplicated LOS implementation,
   **stop and report this** — that would itself be a violation of the
   no-duplicated-guidance-code decision and needs to be flagged before
   proceeding, not silently fixed alongside this patch.
2. Confirm its success/waypoint-advance logic (likely a `geometry()`-style
   helper computing `along`/`cross` independently, same pattern as
   `coupled6-classical-precursor.ts`) does **not** itself need patching — it
   should already use plain Euclidean `distance <= terminal_radius` for
   final-waypoint success, which is unaffected by this fix. Confirm this by
   reading it, don't assume.

## Step 3 — Check existing diagnostics before running anything new

Read `artifacts/rl-campaign/surveyor/p3-v3-final-leg-trajectories.json` and
`artifacts/rl-campaign/surveyor/p3-v4-time-aware-final-leg-trajectories.json`.
Report whether either already shows this same overshoot-past-final-waypoint
pattern on Vehicle A. This is a five-minute check that could mean the bug's
effect on Vehicle A is already partially characterized — don't skip it.

## Step 4 — Re-run the five Vehicle C diagnostic seeds only

Run seeds 30013, 30007, 30003, and the two others from the original
five-seed diagnostic set (do NOT run the full 30000–30049 sweep yet — that
is explicitly blocked until these behaviors are addressed, per standing
decision).

For each of the five, report:
- success / fail and termination reason, before and after the patch
- closest-approach distance to the final waypoint, before and after
- for seed 30013 specifically: the commanded heading in the timestep
  immediately before and immediately after `along >= length` triggers, so we
  can see the size of the discontinuity at the line-to-point handoff and
  whether the yaw-rate limit (0.5236 rad/s) can actually track it

Seed 30003 (adverse wind/current) is explicitly **not** a target for this
fix or for any gain tuning — report its result but do not let it drive any
decision.

## Step 5 — Vehicle A regression (required, not optional)

Run:

```
node --experimental-strip-types validation/rl-campaign/surveyor-calibration.ts
```

This produces `CANDIDATE-NOT-FROZEN` artifacts
(`p2.5-reference.json`, `terminal-radius-sweep.json`, `thresholds.json`,
`task-contract-candidate.json`) — this is expected and correct, it's how this
pipeline already works. Report the new `LOS-PID-v2` success rate from
`thresholds.json` against the existing frozen `reference_rate: 0.66` in
`artifacts/rl-campaign/surveyor/task-contract-frozen.json`.

**Do not freeze anything.** Do not edit `task-contract-frozen.json`. Report
the candidate rate and stop. Freezing the new rate (if it's better) is a
separate, explicit decision, not part of this task.

## Explicit prohibitions

- Do not touch `FROZEN_GAINS` values — this task is a guidance-geometry fix,
  not a gain change.
- Do not run the full 50-seed Vehicle C sweep.
- Do not let seed 30003 influence anything.
- Do not regenerate or hand-wave the `controller_file_sha256` /
  `content_sha256` provenance fields in any frozen artifact — those will go
  stale from this patch by design; note which artifacts reference the old
  hash so they can be regenerated deliberately later, but don't do it as
  part of this task.
- If anything here can't be verified directly (file doesn't exist where
  expected, harness structured differently than assumed), stop and report
  the discrepancy rather than improvising a workaround.

## Report back with

1. Confirmation of harness structure from Step 2.
2. Findings from Step 3.
3. Per-seed before/after results from Step 4, including the 30013 heading-
   discontinuity numbers.
4. The candidate Vehicle A `LOS-PID-v2` success rate from Step 5 vs. 0.66.
5. Any prohibitions violated or assumptions that turned out false.
