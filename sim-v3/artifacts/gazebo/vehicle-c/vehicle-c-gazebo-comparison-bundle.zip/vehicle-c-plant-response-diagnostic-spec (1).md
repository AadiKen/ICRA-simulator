# Task: Vehicle C plant-response diagnostic — seed 30007 only

## Why

For seed 30007, four separate interventions have now come back clean or
irrelevant: the final-waypoint geometry fix didn't apply (not an endpoint
case), the allocator reproduces desired wrench to floating-point precision,
post-lag delivered wrench tracks desired wrench closely (small pre-lag and
post-dynamics gaps, unlike 30000/30048), and a materially different guidance
gain (lookahead 8→4) moved closest-approach by 0.062 m — noise. What hasn't
been checked is whether the wrench that reaches the hull is actually
producing the angular acceleration Vehicle C's own documented plant model
says it should.

**The lookahead=4 candidate is rejected per its pre-registered prediction.**
Do not re-enable it or treat 30013's improvement under it as grounds to keep
it — that's a separate decision this task does not make.

**Scope: seed 30007 only.** No other seed, no sweep.

## Grounding — Vehicle C's own documented plant parameters

From `artifacts/capytaine/vehicle-c-parametric-resolved.json`,
`runtime_parameters`:
- `massProps.inertia.Iz = 240` (kg·m²)
- `damping.linearViscousMatrix6[5][5] = 360`
- `damping.quadraticViscousMatrix6[5][5] = 420`
- `damping.potentialRadiationMatrix6[5][5] = 0.0419` (yaw added mass —
  negligible relative to 240; confirm this is safe to ignore for this check,
  don't silently assume)

Confirm the units and sign conventions these are actually used with in the
physics step (don't assume N·m·s/rad and N·m·s²/rad² match what's plugged
into the equations of motion — verify against how `simulation.ts` or
wherever the coupled6 plant integrator actually consumes this matrix).

## Step 1 — Confirm the equation of motion being used

Locate where `Iz`, `linearViscousMatrix6[5][5]`, and
`quadraticViscousMatrix6[5][5]` are actually consumed in the coupled6 yaw
integration. Write down the exact discrete-time update the sim performs for
yaw rate, including whatever numerical integration scheme (Euler, RK4,
etc.) and timestep it uses. Do not assume a simple
`r_dot = (M_yaw - 360*r - 420*r*|r|) / 240` form until you've confirmed
that's actually what's implemented — report the real one if it differs.

## Step 2 — Log per-timestep, seed 30007 only

- `t_s`
- `yaw_rate_rad_s` (ground truth)
- `delivered_yaw_moment_nm` (`lastFullWrench`'s yaw component, post-lag,
  from the existing wrench-path instrumentation)
- `predicted_yaw_accel` — computed from Step 1's actual equation of motion,
  using the logged `yaw_rate_rad_s` and `delivered_yaw_moment_nm` at that
  instant
- `observed_yaw_accel` — finite-differenced from consecutive
  `yaw_rate_rad_s` samples (state the differencing method: forward, central,
  and the timestep used)
- `residual` — `observed_yaw_accel - predicted_yaw_accel`

## Step 3 — Report

- Does `residual` stay near zero throughout (within a stated numerical
  tolerance you justify, e.g. relative to integration timestep error), or
  does it show a systematic, non-numerical-noise discrepancy? Be explicit
  about which.
- If it matches: report the actual achieved yaw acceleration magnitude
  relative to what would be needed to close the heading error fast enough
  to recapture the route before timeout — i.e. is this a genuine physical
  damping/inertia limit given the commanded moment, not a software bug.
  Show the arithmetic, don't just assert it.
- If it doesn't match: identify where the discrepancy is introduced (wrong
  matrix entry used, added-mass coupling not actually negligible in the
  real integration, sign error, timestep/integration-order issue, etc.) —
  point at the specific code, don't speculate.

## Explicit prohibitions

- Seed 30007 only.
- Do not re-enable or modify the candidate gain set.
- Do not change any physics/damping/inertia parameter — this is read-only
  analysis against the existing documented values.
- Do not run a Vehicle A regression — this doesn't touch shared guidance or
  gains.
- If the equation of motion in Step 1 turns out to be something you can't
  fully characterize from the code, stop and report exactly what's unclear
  rather than guessing at the missing part.

## Report back with

1. The actual discrete equation of motion used (Step 1).
2. The residual behavior verdict (Step 3) — matches or doesn't, with the
   arithmetic shown.
3. If it matches: whether this is a genuine physical limit, with numbers.
4. If it doesn't: the specific code location responsible.
