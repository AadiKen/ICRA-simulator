# Task: audit final-leg gating across all Vehicle C closest-approach numbers reported so far

## Why

Seed 30000's reported "closest approach" (23.525 m, unchanged across the
thrust-increase test) turned out to have occurred while guidance was still
pursuing waypoint 2, not the final waypoint - a geometric coincidence, not
final-leg performance. `closest_final_m`-style metrics that track raw
Euclidean distance to the final waypoint's coordinates continuously through
an episode are not gated on whether guidance has actually started pursuing
that leg, and Vehicle A's own calibration pipeline
(`surveyor-calibration.ts`) tracks `final_leg_activation_rate` precisely
because this is a known failure mode. This task checks whether that same
contamination affects any of the other closest-approach numbers already
used to make decisions in this investigation - not just 30000's.

**Read-only. No code, gain, physics, or actuator changes.**

## Step 1 — Check whether the needed data already exists

For each existing artifact listed in Step 2, check whether per-timestep
`run.waypoint` (or equivalent current-leg index) was logged alongside
distance-to-goal. If yes, final-leg gating can be recomputed retroactively
from existing data with no rerun. If the leg index wasn't logged for a
given artifact, say so explicitly for that artifact rather than silently
skipping it or rerunning without being asked - report which artifacts can
be audited now and which would require a rerun to fix.

## Step 2 — Audit every closest-approach number used in a decision so far

For seeds 30000, 30007, 30013, 30048, across every configuration already
tested:
- Baseline (frozen `LOS-PID-v2` + endpoint geometry fix, no compensation)
- Full-scale Coriolis compensation
- 0.5-scale Coriolis compensation
- Thrust-increase (1000N/500N per pod) + full compensation
- Pod-spacing candidate (30007 only)

For each, determine: did the reported closest-approach distance occur while
`run.waypoint === route.length - 1` (final leg active), or during an
earlier leg? If earlier leg, recompute the correct final-leg-only closest
approach for that seed/configuration from the existing trace (per Step 1) -
report it as "never reached final leg" if that's the case, with the actual
number if it did reach the final leg but the previously-reported figure
just wasn't the true minimum within that leg.

Produce one corrected table: seed x configuration, with both the
originally-reported number and the corrected (final-leg-only) number side
by side, and a flag on any cell where they differ.

## Step 3 — Check the radius calibration separately

The 200-seed terminal-radius calibration
(`artifacts/rl-campaign/vehicle-c/terminal-radius-sweep-candidate.json`,
seeds 30100-30299) used binary `terminal_hits[radius]` success checks, not
a continuous closest-distance metric. Confirm explicitly whether that
success check is itself gated on final-leg activation (i.e. structured like
`coupled6-classical-precursor.ts`'s
`run.waypoint===run.route.length-1 && g.distance<=terminalRadius`) or
whether it could register a hit from the same kind of coincidental
proximity during an earlier leg. State plainly whether the 26% figure at
17.5m (and the rest of that table) needs any correction, or whether it was
never at risk from this issue.

## Step 4 — State what changes

For any cell in the Step 2 table where the corrected number differs
materially from what was reported, say plainly whether it changes a
conclusion already drawn in this investigation (e.g. "seed 30000 never
reaching the final leg under any tested configuration" would mean none of
the saturation/lag findings reported for it actually describe final-
approach behavior at all, and should be read as characterizing leg-2
transit instead). Don't re-litigate the conclusions yourself - just state
which ones now rest on a false premise, in this report.

## Explicit prohibitions

- Read-only audit. No reruns unless Step 1 finds a specific artifact
  genuinely can't be checked otherwise - if so, stop and report which one(s),
  don't rerun without being asked.
- Do not change or re-tune anything based on what this finds.
- Do not touch seed 30003 or run the full sweep.

## Report back with

1. Which artifacts could be audited from existing data vs. would need a
   rerun (Step 1).
2. The corrected seed x configuration table (Step 2).
3. The radius-calibration gating finding (Step 3).
4. Explicit list of which prior conclusions, if any, now rest on a false
   premise (Step 4).
