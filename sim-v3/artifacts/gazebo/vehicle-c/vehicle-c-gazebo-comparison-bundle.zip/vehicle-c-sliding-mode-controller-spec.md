# Task: backstepping + sliding-mode controller for Vehicle C, mirroring Sarda, Qu, Bertaska & von Ellenrieder (2016)

## Source and why

E.I. Sarda, H. Qu, I.R. Bertaska, K.D. von Ellenrieder, "Station-keeping
control of an unmanned surface vehicle exposed to current and wind
disturbances," Ocean Engineering, 2017 (arXiv:1702.04941). Field-trial-
validated on a twin-azimuth-thruster USV (180kg, ~250 kg-m2 yaw inertia -
same order of magnitude as Vehicle C's rigid 240 kg-m2). They found full
PID inadequate for this vehicle class (anti-windup insufficient, couldn't
reach steady state), nonlinear PD/backstepping alone insufficient
(forced a heading-vs-position tradeoff, +-20 deg heading oscillation to
hold position), and sliding mode control the best-performing approach
overall, robust to the actuator-authority limits that have been the
recurring problem in this investigation.

This is a new Vehicle-C-only controller, replacing `losAction`/
`vehicleCDesiredWrench` for Vehicle C entirely - not another gain
candidate. `FROZEN_GAINS`, `ControllerName`, `losAction()`, and everything
Vehicle A's calibration reads stay completely untouched. Build this in a
new module, not inside `portable-controllers.ts`.

**Do not also apply the existing `vehicle-c-coriolis-feedforward.ts`
compensation alongside this controller.** This controller's own `C(v)`
term (below) already performs proper Coriolis compensation as part of a
jointly-designed control law - applying both would double-compensate.
Leave the old feedforward module in place, unused, for this controller.

## Step 1 — Adapt the paper's formulation to waypoint pursuit

The paper tracks a fixed target pose eta_d = [x_d, y_d, psi_d]. Adapt this
to route-following: eta_d is the current active waypoint's coordinates
(north, east) plus a desired heading. For desired heading, use the
path-tangent heading of the current leg (same as existing LOS guidance
computes) rather than inventing a new heading target - keep this part
familiar. eta_d is piecewise-constant: it holds at the current waypoint
until the calling harness's existing waypoint-advance logic (unchanged,
untouched by this task) switches to the next leg, at which point eta_d
jumps to the new target. eta_dot_d = 0 between switches, consistent with
the paper's own station-keeping assumption (eta_dot_d = [0,0,0] since
x_dot_d, y_dot_d, r_d -> 0 at steady state) - state explicitly that this
holds between switches and is discontinuous at switches, and confirm
that's an acceptable, expected transient (the paper's own controller
handles a step-change in target implicitly, since field trials began with
exactly this kind of step: "if the station-keeping command was given with
an initial error in heading and position, all controllers were able to
drive the system to steady-state rapidly").

## Step 2 — Use Vehicle C's real M, C(v), D(v), not the paper's M1/C1/D1

Use the full mass matrix (rigid + added mass), full Coriolis matrix
C(M,nu_r) (the same function already reused for the existing feedforward
work - `coriolisFromMass6()` in `coupledSixPlant.js`), and full damping
matrix (linear + quadratic, from `artifacts/capytaine/vehicle-c-
parametric-resolved.json`) in place of the paper's simplified diagonal
M1/C1/D1. State explicitly that this is an intentional improvement over
the paper's low-speed-diagonal-approximation, justified because Vehicle C
has precise system-identified matrices the paper's authors didn't have.

## Step 3 — Backstepping controller first (paper eq 16-27), as
   infrastructure

Implement the backstepping control law (paper eq 24), adapted per Steps 1-2:

```
tau = M[(J(eta)^T * eta_dot_r) + (J(eta_dot)^T * eta_dot_r)]
      + C(nu_r) * J(eta)^T * eta_dot_r
      + D(nu_r) * J(eta)^T * eta_dot_r
      - J(eta)^T * Kd * s
      - J(eta)^T * Kp * eta_t
```

with reference trajectory `eta_dot_r = eta_dot_d - Lambda * eta_t` (eq 18)
and tracking surface `s = eta_dot_t + Lambda * eta_t` (eq 23).

Derive Lambda using the paper's own three-criteria method (eq 19-21),
applied to Vehicle C's real numbers, not the paper's:
- Resonant mode: estimate the lowest unmodeled resonant frequency for
  Vehicle C the same way the paper did for USV16 (deep-water wave celerity
  at wavelength = vehicle beam, divided by beam) - use Vehicle C's real
  beam (1.98m), not USV16's.
- Actuator delay: use Vehicle C's real 0.35s thrust lag (and note the
  azimuth slew limit separately, since it's a rate limit not a pure time
  constant - the paper's linear-actuator delay was a simpler analog).
- Sampling rate: use bcod-sim's real RK4 timestep (0.05s -> 20Hz), not the
  paper's 4Hz.

Report all three candidate Lambda values and which is selected (the
smallest, per the paper's "slowest decay rate" rule), with the arithmetic
shown.

Choose Kp, Kd initially by the same reasoning already validated in this
investigation (saturation-aware, not naive inertia-matching) - use the
already-derived saturation-aware kp/kd as a starting point/sanity check,
adjusted as needed once this is running against Vehicle C's real M/C/D
rather than the LOS-PID structure they were derived for. Test this
backstepping-only controller against the four diagnostic seeds first, as
a check that the M/C/D/reference-trajectory plumbing is correct, before
adding sliding mode on top - report these results even though backstepping
alone isn't expected to be the final answer (the paper found it
insufficient too), since it validates the infrastructure.

## Step 4 — Sliding mode controller (paper eq 28-30)

Add the integral term to the tracking surface (eq 28) and reference
trajectory (eq 29), and replace the last two terms of the backstepping
law with the boundary-layer saturation term (eq 30):

```
tau = M[...] + C(nu_r)[...] + D(nu_r)[...] - J(eta)^T * R * sat(E^-1 * s)
```

Follow the paper's exact iterative tuning procedure (Section V.C, the
four-step list), not a one-shot derivation:
i. Set each term in E to the steady-state tracking error already observed
   from the frozen `LOS-PID-v2` baseline runs (real data you already have,
   not an assumed value).
ii. Increase R until the system is driven to steady state.
iii. If saturation is constant, increase the corresponding term in E.
iv. If errors are too large, decrease the corresponding term in E.

Add the same anti-windup technique the paper used for the integral term:
scale the accumulated integral error by 0.1 when the control output is
saturated, to prevent windup during saturation (paper Section V.C).

Use the saturation function (`sat`, not signum) to limit chattering, per
the paper.

## Step 5 — Run the four diagnostic seeds

Seeds: 30000, 30007, 30013, 30048. Not 30003, not the full sweep.

Report, for both backstepping-only and sliding-mode results: success/fail,
final-leg-gated closest approach (confirm final-leg activation first,
especially for 30000), heading error behavior over time (the paper's own
metric - report mean/std of heading and position error the same way
Table 6/7 in the paper does, since that's the direct comparison point),
and allocator saturation. Compare against the current best result (frozen
LOS-PID-v2 + geometry fix + full compensation + thrust increases) already
on record for each seed.

## Explicit prohibitions

- Do not modify `FROZEN_GAINS`, `ControllerName`, `losAction()`, or
  anything Vehicle A's calibration reads.
- Do not modify the allocator - reuse `allocatePlanarAzimuthMinimumNorm`
  as-is.
- Do not apply the old Coriolis feedforward module alongside this
  controller.
- Do not modify the harness's existing waypoint-advance/success logic -
  only the wrench-generation logic changes.
- Do not touch seed 30003 or run the full sweep.
- Do not add the paper's output low-pass filter in this task - flag it as
  a fallback option only if sliding mode still shows saturation, don't
  add it preemptively.

## Report back with

1. The eta_d adaptation and confirmation of how waypoint switches are
   handled (Step 1).
2. Confirmation of which M/C/D matrices are used and why (Step 2).
3. The full Lambda derivation with Vehicle C's real numbers, all three
   candidates and the selected value (Step 3), plus backstepping-only
   four-seed results.
4. The sliding-mode tuning process (E and R at each iteration of the
   paper's procedure, not just the final values) and four-seed results
   (Step 4-5), compared against the current best configuration on record.
