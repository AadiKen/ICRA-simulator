# Task: sliding-mode tuning, starting from the empirically-best backstepping configuration

## Correction to the last two tasks

The gate requiring backstepping saturation below ~20-30% before allowing
sliding mode to run was a mistake. Evidence: the original, uncorrected
Kp=486-on-all-axes backstepping configuration (saturating ~100%)
outperformed every subsequent "properly budgeted" gain correction on real
outcomes (closest approaches 1.955m/3.145m/1.918m/2.253m vs. the corrected
version's no-final-leg/8.942m/no-final-leg/2.135m). The likely reason: the
allocator applies a coupled scale under saturation, preserving direction -
so a saturating Kp behaves like "command near-maximum effort in the
correct direction," which is close in spirit to what the sliding-mode
boundary-layer term is supposed to do on purpose. A smaller, unsaturated
Kp avoids clipping but is too weak to close large transient errors within
the episode timeout. The paper never required backstepping to be
saturation-free before moving to sliding mode - that gate was an
unjustified addition on top of the paper's actual method, not part of it.

**Revert to Lambda=0.952381 (the original timing-derived value, not the
force-budget-reduced 0.143980375) and Kp=[485.995, 485.995, 485.995]
(the original single scalar, not the per-axis budgeted values) as the
starting configuration for this task.** Do not re-derive them further -
use exactly the values from the first backstepping task, which produced
the best results seen so far.

## Step 1 — Confirm the starting point

Re-run backstepping-only with this reverted configuration on the four
diagnostic seeds to confirm it reproduces the original results (1.955m,
3.145m, 1.918m, 2.253m closest approaches) - a sanity check that nothing
else changed in the meantime (M/C/D, waypoint logic, allocator all should
still be exactly as originally built).

## Step 2 — Sliding mode, following the paper's procedure without a
   saturation-avoidance precondition

Add the sliding-mode boundary-layer term (paper eq 28-30) on top of this
reverted backstepping base, exactly as originally implemented (integral
term, anti-windup at 10% scaling under saturation, `sat` not signum).

Follow the paper's iterative tuning procedure again, but this time without
requiring backstepping to already be unsaturated first - the procedure
itself is designed to work from a saturating starting point:
i. Set E to the steady-state tracking error already observed (reuse
   E_0=[29.003, 17.882, 1.845] from before, or refresh if a more precise
   number is available from this task's Step 1 re-run).
ii. Increase R until the system is driven to steady state.
iii. If saturation is constant, increase E.
iv. If errors are too large, decrease E.

Run this iteration a reasonable number of times (report how many, use
judgment rather than an arbitrary cap this time - the goal is following
the paper's actual procedure to a real conclusion, not hitting a count).
Report the trajectory of E, R, and outcomes at each iteration, the same
way the first sliding-mode attempt did.

## Step 3 — Report against the real comparison point

For the final accepted tuning (or the best iteration if none clearly
converges), report success/fail, final-leg-gated closest approach,
position/heading error mean+-SD, and saturation per axis for all four
seeds - compared against:
- The original backstepping-only results (this task's Step 1).
- The current best PID-based configuration on record.
- The (now understood to be a red herring) per-axis-corrected-gains
  attempt, noting explicitly why it's not the right comparison baseline
  going forward.

## Explicit prohibitions

- Do not re-derive Lambda or Kp/Kd via the force-budget method again in
  this task - use the reverted original values as the fixed starting
  point for sliding-mode tuning.
- Do not modify M/C/D, the allocator, or waypoint logic.
- Do not touch `FROZEN_GAINS`, `ControllerName`, `losAction()`, or
  anything Vehicle A's path reads.
- Do not touch seed 30003 or run the full sweep.
- Do not add the paper's output low-pass filter in this task - still held
  as a fallback if sliding mode's own boundary-layer mechanism turns out
  not to be sufficient on its own.

## Report back with

1. Step 1's confirmation that the reverted configuration reproduces the
   original results.
2. The sliding-mode tuning trajectory (E, R, outcomes per iteration).
3. Final results compared against all three baselines named in Step 3.
