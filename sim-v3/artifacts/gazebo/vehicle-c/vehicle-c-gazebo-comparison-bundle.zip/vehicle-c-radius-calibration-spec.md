# Task: Vehicle C terminal-radius calibration — build and run, do not freeze

## What this is and isn't

Vehicle C's 2 m terminal radius was inherited unmodified from Surveyor's
calibration (`surveyor-calibration.ts`), which explicitly derived it from
Surveyor's own 1.83 m length (`defensibility_ceiling_m = 5 * vehicle_length_m
= 9.15 m`, band-selected within that). Vehicle C is 3.5 m — no Vehicle
C-specific radius calibration has ever been run. This task runs the same,
already-approved-for-Surveyor methodology against Vehicle C's own length,
producing a **candidate, not-frozen** result, exactly like Surveyor's own
calibration artifacts do. This is not "loosening the bar" — it's completing
a per-vehicle step the existing protocol was designed to require and that
was skipped for Vehicle C.

This task does **not** re-run or re-derive the return-threshold /
bootstrap-CI / task-contract-candidate portions of Surveyor's full
calibration pipeline. Scope is the terminal-radius sweep only. If the
radius result looks usable, the rest of the calibration apparatus is a
separate, later task.

## Step 1 — Extract or parameterize the sweep logic

`surveyor-calibration.ts`'s terminal-radius-sweep logic (the block producing
`terminal-radius-sweep.json` / `terminal-radius-sweep-fine.json`) is
currently hardcoded to Surveyor's `vehicle_length_m: 1.83`. Either:
(a) extract the sweep into a vehicle-parameterized function both scripts can
call, or (b) write a new `vehicle-c-radius-calibration.ts` that duplicates
only the sweep logic with Vehicle C's parameters substituted in. Prefer (a)
if it's a clean extraction; don't force it if the surrounding code makes
that risky under time pressure — (b) is acceptable, just don't silently
duplicate the return-threshold logic while you're in there, scope stays
radius-only.

Vehicle C parameters to substitute (from
`validation/gazebo-vehicles/vehicle-c-parameter-map.json`):
- `vehicle_length_m: 3.5`
- `defensibility_ceiling_m: 17.5` (5 x length, same multiplier as Surveyor)
- `defensible_minimum_m: 1.75` (0.5 x length, same fraction as Surveyor's
  half-vehicle-length floor)

Confirm whether Surveyor's GPS-comfort floor check (1.6 m,
`gps_horizontal_sigma_m_per_axis: 0.8`) uses a GPS noise model specific to
Surveyor's sensor config or a generic one Vehicle C shares. If Vehicle C has
its own GPS/sensor noise parameters recorded anywhere, use those; if none
exist, carry Surveyor's noise floor over explicitly labeled as "borrowed,
not independently verified for Vehicle C" rather than silently presenting
it as Vehicle-C-derived.

Same selection rule as Surveyor: smallest radius maximizing separation
ratio between untrained and best-classical success, subject to the 40-70%
band, and passing both the defensibility-ceiling and GPS/length sanity
checks.

## Step 2 — Vehicle C controller configuration to test

Use the current best-known Vehicle C configuration, not the bare baseline
and not the rejected candidate:
- Shared `losAction("LOS-PID-v2", ...)` with the endpoint-geometry fix
  (already merged).
- **Full-scale** Coriolis feedforward compensation (`tau_comp = C(M,nu_r)*nu_r`,
  scale 1.0) — this was the configuration with the closest approaches
  (5.2-7.5-5.7 m range on three of four diagnostic seeds), not the rejected
  0.5-scale variant.
- Do not use `losActionCandidate`/`VEHICLE_C_CANDIDATE_GAINS` (rejected).

State this configuration explicitly in the output artifact so it's
unambiguous which Vehicle C setup the radius was calibrated against.

## Step 3 — Use a held-out seed range, not the diagnostic seeds

30000, 30003, 30007, 30013, and 30048 have all been directly used to
diagnose and tune this controller (geometry fix, gain candidate, two
compensation scales). Calibrating the radius against the same seeds would
be circular — the radius would be fit to exactly the runs it's being
validated against. Use a fresh seed range not previously touched (e.g. the
next block after 30048, or whatever range keeps this cleanly separate from
the tuning seeds — state which range you used and why it doesn't overlap).
Use enough seeds for the sweep to be meaningful (Surveyor used 200 episodes
per policy; use as many as time allows, but state the actual count used and
don't silently under-power this relative to Surveyor's precedent without
saying so).

## Step 4 — Run and report

Produce the candidate radius-sweep artifact (same shape as
`terminal-radius-sweep.json`/`-fine.json`: candidate radii, cells with
untrained/los_pid/los_speedcap rates and separation ratios, sanity checks,
`decision: { human_approval_required: true, frozen: false }`,
`status: "..._HALT_FOR_REVIEW"` or equivalent). Do not touch
`task-contract-frozen.json`. Do not present any radius as adopted.

Report plainly:
- Whether an eligible radius was found in the 40-70% band passing both
  sanity checks.
- If found: the selected radius, and how it compares to where the current
  best configuration's closest-approach distances already land (5.2-7.5-5.7 m
  range) — i.e. would this radius already turn some of the diagnostic
  seeds' results into passes, given they're informative context even
  though they weren't used for the calibration itself.
- If not found: why (band, ceiling, or GPS floor failure), same as
  Surveyor's own halt conditions report.

## Explicit prohibitions

- Do not modify `task-contract-frozen.json` or freeze anything.
- Do not touch Surveyor/Vehicle A's own calibration artifacts.
- Do not re-run or re-derive the return-threshold/bootstrap/contract-
  candidate portions of the Surveyor pipeline for Vehicle C in this task.
- Do not use the diagnostic seeds (30000, 30003, 30007, 30013, 30048) for
  the calibration run itself.
- Do not use the rejected gain candidate or the 0.5-scale compensation.
- If Vehicle C has no equivalent of Surveyor's untrained-policy baseline or
  GPS noise model readily available, stop and report what's missing rather
  than inventing one.

## Report back with

1. Which extraction approach was used (Step 1) and the substituted
   parameters.
2. Confirmation of the exact controller configuration tested (Step 2).
3. The seed range used and confirmation of no overlap with diagnostic seeds
   (Step 3).
4. The full sweep result and eligibility verdict (Step 4).
